export const RequiredGuestInfoAlert = () => {
    return (
        <div style={{
            padding: "16px",
            backgroundColor: "#f3f4f6",
            borderRadius: "8px",
            margin: "16px 0",
            textAlign: "center"
        }}>
            <p style={{ margin: "0 0 8px 0", fontSize: "14px", color: "#374151" }}>
                Please complete your billing information to initialize the payment form.
            </p>
            <small style={{ fontSize: "12px", color: "#6b7280" }}>
                Required: Email, Name, Address, City, Postcode, and Country
            </small>
        </div>
    )
}