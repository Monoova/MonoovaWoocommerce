# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.1.8] - 2025-10-06

### Fixed
- **Card Payment Amount Updates** - Fixed incorrect payment amount when updating shipping method during checkout
  - Resolved issue where Primer SDK session token was created with outdated cart total before shipping method changes
  - Implemented cart total and shipping data capture during token generation phase instead of payment completion
  - Added automatic cart monitoring to detect total changes and regenerate SDK session token with updated amounts
  - Enhanced order recalculation in `ajax_get_client_token()` to ensure token payload contains correct `currencyAmount`
  - Improved user experience by ensuring card payment amounts always reflect current cart state with correct shipping costs

- **Webhook Order Lookup Reliability** - Enhanced webhook handler to prevent "Order not found" errors for valid orders
  - Added comprehensive logging to track meta key queries and identify lookup failures
  - Implemented fallback mechanism to extract order ID from reconciliation reference format (e.g., `WC648T1759326320P`)
  - Added validation to ensure extracted orders match the expected reference in meta data
  - Improved webhook processing reliability for PayID and Bank Transfer payments

- **Automatcher Account Generation** - Fixed reusable PayID persistence when regenerating Automatcher account
  - Implemented automatic reset of reusable PayID and order counter when new Automatcher account is generated
  - Uses PayID-specific testmode setting to determine correct mode (test/live) for PayID reset
  - Ensures fresh PayID generation for orders after Automatcher account changes

### Enhanced
- **Primer SDK Reinitialization** - Improved cart change handling for Card payments
  - Added container cleanup to remove existing SDK iframe before reinitialization
  - Implemented forced reinitialization with new token when cart totals change
  - Enhanced payment flow stability when switching between shipping methods during checkout

## [1.1.7] - 2025-09-30

### Fixed
- **PayID Cart Total Updates** - Fixed cart total amount not updating on PayID instruction regeneration
  - Resolved issue where PayID instructions displayed outdated cart totals when shipping or discount changes occurred
  - Enhanced cart monitoring to detect total changes and automatically regenerate PayID instructions with updated amounts
  - Improved user experience by ensuring payment amounts always reflect current cart state

- **PayID/Bank Transfer Reconciliation Rules** - Enhanced reconciliation rule generation for dynamic cart changes
  - Implemented forced regeneration of reconciliation rules when cart total amount changes during PayID checkout
  - Added shipping method data capture and storage for accurate order reconciliation
  - Ensured payment instructions always include current cart totals and shipping information

- **Persistent Payment Container Improvements** - Enhanced UI state persistence for PayID and PayTo payments
  - Improved `usePersistentPaymentDetailsContainer` to better store and restore current UI state
  - Fixed payment form state preservation across page reloads and navigation
  - Enhanced container initialization and state management for consistent user experience

- **Radio Button CSS Styling** - Fixed CSS styling issues on mobile UI for PayID and Bank Transfer radio button selections

- **Order Received Page Shipping Method Display** - Fixed incorrect shipping method names displayed after successful payments
  - Resolved issue where Order Received page showed wrong shipping method (e.g., "Flat rate" instead of "Pickup")
  - Enhanced webhook handling to update shipping method names based on customer selections during checkout
  - Implemented shipping method data storage and retrieval for accurate order display
  - Applied fixes for both PayID and PayTo payment methods

### Enhanced
- **PayTo Agreement Creation** - Improved PayTo agreement creation to capture shipping method data before authorization
  - Added cart state capture functionality to store shipping and discount information at agreement creation time
  - Enhanced order total accuracy for PayTo payments by preserving cart state from checkout
  - Improved webhook processing to use stored shipping method data for order updates

## [1.1.6] - 2025-09-24

### Fixed
- **Admin Payment Settings Navigation** - Fixed broken settings shortcuts by adding section_tab URL parameter
  - Updated gateway redirect URLs to include section_tab parameter for direct navigation
  - Fixed Card Gateway redirect to navigate to Card settings tab (`&section_tab=card_settings`)
  - Fixed PayID Gateway redirect to navigate to PayID settings tab (`&section_tab=payid_settings`)
  - Added missing PayTo Gateway redirect method to navigate to PayTo settings tab (`&section_tab=payto_settings`)
  - Enhanced JavaScript to read URL parameters and automatically select the correct settings tab
  - Updated plugin action links and dashboard buttons to use proper section_tab navigation

- **Dashboard Statistics Accuracy** - Resolved incorrect payment statistics limited to 10 orders
  - Fixed WooCommerce order query default limit issue causing statistics to show only first 10 orders
  - Corrected today's, monthly, and all-time transaction counts to reflect accurate totals
  - Fixed payment method counts (Card, PayID, PayTo) to include all successful payments
  - Transaction list now shows all available transactions including draft, pending, and failed statuses

- **Primer SDK 3DS Validation Recovery** - Fixed iframe suspended state after failed 3D Secure validation
  - Implemented client session refresh mechanism to recover from failed 3DS attempts
  - Added automatic session regeneration when Primer SDK enters suspended state
  - Enhanced error handling to allow users to retry payments after 3DS failures
  - Improved user experience by preventing checkout form from becoming permanently unusable

### Enhanced
- **Apple Pay Cross-Origin Support** - Added merchantDomain field to Primer SDK options
  - Added `merchantDomain: window.location.hostname` to primerOptions configuration
  - Enhanced Apple Pay compatibility when checkout is rendered in cross-origin iframe
  - Applied to both regular checkout (`usePrimerCheckoutInitialization.js`) and express checkout (`monoova-card-express-block.js`)
  - Ensures Apple Pay functions correctly in embedded payment scenarios

## [1.1.5] - 2025-09-18

### Fixed
- **PayID Reference Field Display** - Fixed PayID reference field visibility control in checkout
  - Resolved issue where the reference field setting in admin was not properly reflected in frontend blocks
  - Added missing `payid_show_reference_field` setting to unified gateway settings collection
  - Reference field can now be properly enabled/disabled from PayID admin settings
- **Email Validation in Checkout** - Enhanced email validation for all payment methods (Card, PayID, PayTo)
  - Updated email validation regex to require minimum 2 characters after dot symbol
  - Improved user experience by preventing invalid email formats during checkout
- **PayID Payment Email Timing** - Fixed premature order confirmation email sending for PayID payments
  - Resolved issue where order received emails were sent before user completed payment reconciliation
  - Email notifications now properly wait for payment confirmation via webhook

### Enhanced
- **Settings Architecture** - Improved unified gateway settings to properly collect all gateway-specific configurations
- **Email Format Validation** - Strengthened email validation across all payment methods with more robust regex patterns

## [1.1.4] - 2025-09-05

### Fixed
- **Card Gateway Express Checkout** - Fixed incorrect express checkout checking logic after completing card payment session
  - Resolved issue where express checkout validation was incorrectly triggered during normal card payment completion

## [1.1.3] - 2025-08-25

### Added
- **Spinner Loading UI Configuration** - Added customizable spinner loading settings for both PayID and PayTo payment methods
  - **Color Customization** - Configure spinner border color (default: #2CB5C5)
  - **Size Control** - Adjust spinner dimensions in pixels (default: 20px, applies to both width and height)

- **Copy Button UI Configuration** - Added customizable copy button styling for PayID payment method
  - **Icon Color Control** - Configure SVG stroke color for copy button icons (default: #2CB5C5)
  - **Consistent Styling** - Applied to all copy buttons (PayID value, reference, BSB, account number)

### Enhanced
- **Admin Settings Interface** - Extended PayID and PayTo checkout UI style settings with new configuration options
  - **Organized Settings Layout** - Added dedicated sections for spinner loading and copy button customization
  - **Intuitive Controls** - Color picker for colors, number input for spinner size with validation

### Fixed
- **Required Guest Information Alert** - Update UI style for the alert of required guest information to all match Card, PayID and PayTo 


## [1.1.2] - 2025-08-21

### Enhanced
- Updated PayID and PayTo blocks to utilize dynamic styles from admin settings for pay labels/amounts and pay button.
- Integrated new UI style settings for PayID and PayTo blocks, allowing for customizable font sizes, weights, colors, and button styles.
- Ensured consistent styling across payment methods by applying settings from the admin configuration.

## [1.1.1] - 2025-08-14

### Fixed
- **PayTo Maximum Amount Display** - Removed duplicate "$" sign in maximum amount input field after clicking "Accept and Continue" button
- **PayTo Agreement Text** - Removed unnecessary exclamation mark from PayTo agreement authorization text for cleaner presentation

## [1.1.0] - 2025-08-14

### Fixed
- **Radio Button UI Consistency** - Fixed minor styling inconsistencies in PayID and PayTo radio button components
- **Payment Method Font Standardization** - Resolved font size inconsistencies between different payment method options
- **"Pay With" Text Sizing** - Reduced "Pay With" header text size to maintain consistency with other interface elements

### Improved
- **Visual Harmony** - Enhanced overall visual consistency across payment method selection interfaces
- **Typography Consistency** - Standardized text sizing throughout payment forms for better user experience
- **Interface Polish** - Minor UI refinements for improved visual coherence between PayID and PayTo components

## [1.0.9] - 2025-08-13

### Improved
- **PayTo Block UI Consistency** - Standardized font sizes, colors, and styling across PayTo payment components to match PayID component design
  - **Font Standardization** - Updated all text elements to use consistent font sizes (24px for headers, 16px for labels, 12px for field labels)
  - **Color Harmonization** - Unified color scheme using `#333` for main text, `#666` for labels, `#555` for descriptions, and `#484848` for status text
  - **Background Consistency** - Standardized input field backgrounds to `#f8f9fa` and borders to `#e8e8e8`
  - **Component Modernization** - Replaced all custom input elements with WordPress standard `TextControl` components for better accessibility and maintainability

### Enhanced
- **Input Field Improvements** - Upgraded all PayTo form inputs to use WordPress `@wordpress/components` TextControl
  - **Currency Input Enhancement** - Added "$" prefix adornment to maximum payment amount field for clear currency indication
  - **Decimal Input Support** - Enhanced number input handling to support decimal values, empty states, and international formats
  - **Smart Input Validation** - Improved onChange handlers to allow partial decimal inputs (e.g., "100.", ".5") and support both "." and "," decimal separators
  - **Error State Styling** - Enhanced error handling with consistent red border styling and proper validation feedback

### Technical Changes
- **Component Architecture** - Migrated from custom HTML input elements to WordPress standard TextControl components
- **CSS Optimization** - Added comprehensive styling for TextControl components including focus states, error states, and read-only styling
- **Input Handling Logic** - Implemented sophisticated decimal input parsing that preserves user typing flow while maintaining data integrity

## [1.0.8] - 2025-08-11

### Fixed
- **WooCommerce Subscriptions Compatibility** - Resolved critical issue where payment gateways disappeared when WooCommerce Subscriptions plugin was activated
- **Admin Settings JavaScript Loading** - Fixed JavaScript loading issues for admin payment settings interface when WooCommerce Subscriptions was active
- **Class Initialization Timing** - Fixed initialization order conflicts between Monoova plugin and WooCommerce Subscriptions

### Improved
- **Subscription Integration Reliability** - Enhanced initialization timing to prevent conflicts with subscription plugin
- **Error Handling** - Added safety checks for gateway registration and initialization
- **Debug Capabilities** - Added debug logging for subscription integration troubleshooting
- **Plugin Compatibility** - Properly declared compatibility with WooCommerce Subscriptions

### Technical Changes
- Delayed subscription class initialization until after gateways are properly registered
- Moved admin settings handler and admin class initialization to proper hooks
- Added class existence checks before gateway registration
- Enhanced webhook handler initialization timing
- Added WooCommerce Subscriptions compatibility declaration

## [1.0.7] - 2025-08-05
- Added PayTo payment gateway with mandate management
- Implemented WooCommerce Subscriptions integration
- Enhanced admin dashboard with PayTo statistics
- Added express checkout option for Card or PayTo payment methods in the admin settings
- Improved error handling and user experience
- Added comprehensive webhook handling for all gateways

## [1.0.6] - 2025-07-22
### Fixed
- Fixed webhook handler for NPPReceivePayment to detect this event by the only field `ReconciliationRuleReference` (remove the checking field `SourceBankAccount` as we don't always have source account info available) 

## [1.0.5] - 2025-07-21

### Added
- **Webhook Configuration Management** - New comprehensive webhook management system in General Settings
  - **Separate Sandbox and Live Mode Configuration** - Independent webhook management for testing and production environments
  - **Auto-Status Checking** - Automatic verification of webhook subscription status for all required events
  - **One-Click Webhook Registration** - Simple "Connect" button to register all necessary webhook subscriptions
  - **Real-time Status Indicators** - Visual status chips showing "Active" or "Inactive" webhook states
  - **API Credentials Validation** - Smart validation that prevents webhook operations when API credentials are missing
  - **Comprehensive Event Coverage** - Supports all required webhook events:
    - **Card API Events**: CreditCardPaymentNotification, CreditCardRefundNotification
    - **PayTo API Events**: PaymentAgreementNotification, PaymentInstructionNotification
    - **Payments API Events**: NppReturn, NppPaymentStatus, PayToReceivePayment, NPPReceivePayment, InboundDirectCredit, NPPCreditRejections, InboundDirectCreditRejections

### Improved
- **Enhanced Admin Experience** - Streamlined webhook setup process with clear visual feedback
- **Automatic Configuration Detection** - System automatically detects and validates API configuration before allowing webhook operations
- **Error Prevention** - Prevents invalid webhook subscription attempts when credentials are incomplete
- **Real-time Updates** - Webhook status updates automatically when API credentials are configured
- **User Guidance** - Clear error messages guide administrators to complete required configuration steps

### Fixed
- **Webhook Subscription Error Handling** - Improved error handling for existing webhook subscriptions (HTTP 400 responses)
- **API Response Processing** - Fixed array operator error in API response handling for webhook subscription conflicts
- **Mode-Specific API Calls** - Webhook operations now use correct API credentials and URLs based on selected mode (Sandbox/Live)

---

## [1.0.4] - 2025-07-16

### Fixed
- Fixed empty billing data when creating card token with a guest user
- Updated PayID instructions text from "Scan to pay" to "Pay" for better user experience

---

## [1.0.3] - 2025-07-14

### Added
- Integrated Card SDK and PayID instruction section directly into WooCommerce checkout flow
- Improved PayID flow with enhanced reusability - generate and reuse 1 PayID for up to 10 orders instead of creating new PayID for each order
- Enhanced webhook processing for PayID overpayment/underpayment scenarios via NPPRejection handling
- **Auto-navigation to Order Received page** - After successful PayID payment confirmation, users are automatically redirected to the Order Received page after a 5-second countdown

### Fixed
- Fixed scroll broken UI in the Express checkout dialog
- Fixed webhook handler for PayID payments in case of overpayment/underpayment - now properly handled by NPPRejection instead of processing as successful payment
- Improved payment flow stability and user experience during checkout

### Changed
- Removed redirect page dependency for Card SDK integration
- Moved PayID instructions from Order Received page to checkout page for better user experience
- Updated payment processing logic to handle edge cases more reliably
- **Enhanced payment success flow** - Payment confirmation now includes visual countdown timer and automatic navigation to order details

### Improved
- Enhanced checkout experience with inline payment processing
- Better error handling and user feedback during payment flows
- Optimized PayID generation and management for better performance
- **Streamlined post-payment experience** - Users no longer need to manually navigate to order details after payment confirmation

---

## [1.0.2] - Previous Release
*Previous changelog entries would go here*

## [1.0.1] - Previous Release
*Previous changelog entries would go here*

